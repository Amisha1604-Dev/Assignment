﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Collections;
using System.IO;
using System.Configuration;
using log4net;
using AjaxControlToolkit;
using System.Globalization;
using System.Text;
using MySql.Data.MySqlClient;
using Org.BouncyCastle.Bcpg.OpenPgp;

public partial class StudentRegistration_Student_Search : System.Web.UI.Page
{
    private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

    protected void Page_Load(object sender, EventArgs e)
    {

        log.Debug("Inside EMR_EMRSearch_PageLoad");
        if (!Page.IsPostBack)
        {
            dataBind();

        }
    }

    protected void rptStudent_ItemCommand(object source, RepeaterCommandEventArgs e)
    {

    }



    protected void GridView2_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        ImageButton EditButton = (ImageButton)e.Row.FindControl("BtnEdit");
    }

    protected void ButtonSearchOnClick(object sender, EventArgs e)
    {
        try
        {
            log.Debug("Patient entry: ButtonSearchOnClick");

            dataBind();


        }
        catch (Exception ex)
        {
            log.Error(" Error in Patient entry on ButtonSearchOnClick" + ex);
            log.Error(" Stack Trace " + ex.StackTrace);
            string CloseWindow = "alert('Error!')";
            ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "CloseWindow", CloseWindow, true);
            return;
        }
    }
    private void dataBind()
    {
        Business obj = new Business();
        List<Student> patients = obj.SelectPatientDetails();
        rptStudent.DataSource = patients;
        rptStudent.DataBind();
    }
    protected void btnView_Command(object sender, CommandEventArgs e)
    {
        // Get the full path from CommandArgument (this is passed from the Repeater control)
        string fullPath = e.CommandArgument.ToString();

        if (!string.IsNullOrEmpty(fullPath))
        {
            // Extract only the file name (e.g., "ASHITHARESUME.pdf") from the full path
            string docName = Path.GetFileName(fullPath);
            docName = "~/Uploads/" + docName; 
            // Resolve the virtual path for the document in the application
            string virtualPath = docName;  // Resolves the file path to a virtual path

            // Get the physical path of the document to check if it exists
            string physicalPath = Server.MapPath(docName);  // Convert to physical path on the server

            // Check if the file exists at the physical path
            if (File.Exists(physicalPath))
            {
                // If file exists, open it in a new tab or window
                string script = "window.open('{virtualPath}', '_blank');";
                ClientScript.RegisterStartupScript(this.GetType(), "OpenFile", script, true);
            }
            else
            {
                // If the file doesn't exist, show an alert
                ClientScript.RegisterStartupScript(this.GetType(), "FileNotFound", "alert('File not found!');", true);
            }
        }


    }
}
