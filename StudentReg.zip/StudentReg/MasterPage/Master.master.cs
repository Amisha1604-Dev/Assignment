﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using AjaxControlToolkit;
using log4net;
using System.Text.RegularExpressions;
using MySql.Data.MySqlClient;

public partial class MasterPage_Master : System.Web.UI.MasterPage
{
    private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    public string authSpace = "$";
    public string str;
    public SqlConnection con;
    public SqlCommand cmd;
    public string cmdString;
    public string sHTML;
    DataAccess obj = new DataAccess();
    protected void Page_Init(Object sender, EventArgs e)
    {
        if (Session["UserId"] == null || Session["UserId"].ToString() == "")
        {
            Session.Abandon();
            Response.Redirect("~/Login.aspx");
        }

    }
    protected void Page_Load(object sender, EventArgs e)
    {
        lblname.Text = Session["UserName"].ToString();

        if (!IsPostBack)
        {

            if (!Page.IsPostBack)
            {
                //DataTable dt = this.GetData(0);
                //PopulateMenu(dt, 0, null);
                //lblname.InnerHtml = Session["UserName"].ToString();
                sHTML += "<ul class='navigation-menu'>";
                getMenu();
                sHTML += "</ul>";
                mainmenu.InnerHtml = sHTML;
            }
        }


        
       
    }
    public void getMenu()
    {

           
    }

    protected void lnklogout_Click(object sender, EventArgs e)
    {
        Session.RemoveAll();
        Session.Abandon();
        Response.Redirect("~/Login.aspx");
    }

    protected void lnkbtnprofile_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/UserManagement/UserProfile.aspx");
    }

    protected void lnkbtnpwd_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/UserManagement/ChangePassword.aspx");
    }
}
