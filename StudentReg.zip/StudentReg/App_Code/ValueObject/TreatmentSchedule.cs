﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for TreatmentSchedule
/// </summary>
public class TreatmentSchedule
{
    public int Cluster { get; set; }

    public string Hospitalnum { get; set; }

    public string patient_name { get; set; }

    public string ConsulatantIncharge { get; set; }

    public string TMB1 { get; set; }

    public string TMB2 { get; set; }

    public string TMB3 { get; set; }

    public DateTime Tmb_decisiondate { get; set; }

    public string Enterdby { get; set; }

    public DateTime Enterddate { get; set; }

    public string Cancelled { get; set; }

    public string CancelledRemark { get; set; }

    public string Cancelledby { get; set; }

    public DateTime Cancelleddate { get; set; }

    public string moderator { get; set; }
}