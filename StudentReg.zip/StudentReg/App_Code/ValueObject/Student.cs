﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Patient
/// </summary>
public class Student
{
    public string RollNo { get; set; }
    public string StudentName { get; set; }
    public string AadharNo { get; set; }
    public string Gender { get; set; }
    public string MobileNo { get; set; }
    public string EmailID { get; set; }
    public string FName { get; set; }
    public string Mname { get; set; }
    public string DocPath { get; set; }
    public string DOB { get; set; }



}