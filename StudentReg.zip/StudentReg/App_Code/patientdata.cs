﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class patientdata
{
    public int ChiefComplaintID { get; set; }
    public string Eye { get; set; }
    public string DurationText { get; set; }
    public string DurationID { get; set; }
    public string Hospitalnum { get; set; }
    public string PatientName { get; set; }
    public string Diseasesite { get; set; }
    public int Age { get; set; }
    public string Gender { get; set; }
    public string Category { get; set; }
    public string Nextfollowup_date { get; set; }
    public string Lasttfollowup_date { get; set; }
    public string Status { get; set; }
    public string Insurance { get; set; }
    public string Reg_date { get; set; }
    public string Email_id { get; set; }
    public string P_Tel_no { get; set; }
    public string Permanent_address { get; set; }
    public string Local_address { get; set; }
    public string L_ContactNo { get; set; }
    public string Immediatekinname;
    public string I_contactno;
    public string relationship;
    public string I_Address;
    public DateTime DOB;
    public string identifaicationmark;
    public int maritalstatus;
    public string spousedetails;
    public string education;
    public string occupation;
    public string familyincome;
    public int mothertongue;
    public string religion;
    public string nationality;
    public string Refereingdoctorname;
    public string Hospital;
    public string H_Contactno;
    public string refereingdocaddress;
    public string unit_department;
    public string visit_discription;
    public string consultingdoctorname;
    public string consultingdoctorname1;
    public string consultingdoctorname2;
    public string consultingdoctorname3;
    public string consultingdoctorname4;
    public string consultingdoctorname5;
    public string patientreferdbtype;
    public string emergency;
    public string emergency_date; //SN-03-06-2020
    public string gendersesc { get; set; }
    public string Month { get; set; }
    public string IsPatientflag { get; set; }
    //SN-29-07-2020
    public string PR { get; set; }
    public string BP { get; set; }
    public string Temp { get; set; }
    public int Pain_Score { get; set; }
    public bool pain;
    //SN-29-07-2020

    public DateTime visitdate { get; set; }

    public string next_Unit { get; set; }

    public string Referedby { get; set; }

    public string Refercomment { get; set; }

    public string Referreason { get; set; }

    public string Height { get; set; }

    public string Weight { get; set; }

    public string Nononcounit { get; set; }

    public string Isfilegenearated = "Y";

    public int entryno { get; set; }

    public int referalentryno { get; set; }

    public string IsNonOncoflag { get; set; }

    public string hospnofornononcology { get; set; }

    public string trackisnononcoflag { get; set; }

    public string IsMedOncoOldflag { get; set; }

    public string Final_Treatment_Plan { get; set; }
}
