﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for EmailDetails
/// </summary>
public class EmailDetails
{
    public string Id;
    public string Type;
    public string AppId;
    public string MsgBody;
    public string FromEmail;
    public string ToEmail;
    public string EmailSubject;
    public string CCEmail;
    public string BCCEmail;
    public string Module;
    public string IsSent;
    public string BoxID;
    public string UnitId;
    public string PartNumber;
    public string NoOfRecipents;
    public string IsBulkyMail;
    public string Message_ID;
    public string SentBy;
    public string Remarks;

    public string PatientName;
    public string ContactNo;
    public string message;
    public string doctor;
    public DateTime onlyDate;
}