﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;


public class Business
{
    DataAccess d = new DataAccess();
    DALEMR g= new DALEMR();
    Student obj = new Student();

    public ArrayList GetUserRole(string userid)
    { 
        try
        {
            return d.GetUserRole(userid);
        }
        catch
        {
            throw;
        }
    }
    public StudentDatam Get_UserDetails(string emailid, string Pass)
    {
        try
        {
            return d.Get_UserDetails(emailid, Pass);
        }
        catch
        {
            throw;
        }
    }
    public int insertPatientData(Student d)
    {
        try
        {

            return g.insertPatientData(d);
        }
        catch
        {
            throw;
        }

    }
   
    public List<Student> SelectPatientDetails()
    {
        try
        {
            return g.SelectPatientDetails();
        }
        catch
        {
            throw;
        };
    }
   
}
