﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


public class Generalworkup
{
    public int entryno;
    public string filepath;
    public int docsize;
    public string Hospitalnum { get; set; }
    public string PatientName { get; set; }
    public int Age { get; set; }
    public string Gender { get; set; }
    public string Pasthistory { get; set; }
    public string Others { get; set; }
    public string Details { get; set; }
    public string Comorbidities { get; set; }
    public string ComorbiditiesOthers { get; set; } //22-12-2020
    public string Medications { get; set; }
    public string Treatment_Received { get; set; }
    public string S_Type { get; set; }
    public DateTime S_Date { get; set; }
    public string S_Hospital { get; set; }
    public string S_Place { get; set; }
    public string S_Operating_surgeon{ get; set; }
    public int S_Entryno { get; set; }
    public string S_Details { get; set; }
    public string R_Total_dose { get; set; }
    public string R_Fractions { get; set; }
    public string R_Hospital { get; set; }
    public string R_Place { get; set; }
    public string R_Radiation_oncologist{ get; set; }
    public DateTime R_Startdate{ get; set; }
    public DateTime R_completiondate{ get; set; }
    public int R_Entryno { get; set; }
    public string C_Drug { get; set; }
    public string C_Dose { get; set; }
    public string C_Cycles { get; set; }
    public string C_Hospital { get; set; }
    public string C_Place { get; set; }
    public string C_Medical_oncologist { get; set; }
    public DateTime C_Startdate { get; set; }
    public DateTime C_completiondate{ get; set; }
    public int C_Entryno { get; set; }
    //public int Investigation_type { get; set; }
    public string Family_history { get; set; }
    public int Diet { get; set; }
    public string Appetite { get; set; }
    public int Habits { get; set; }
    public int Habits_duration { get; set; }
    public string Habits_Status { get; set; }
    public int Sleep { get; set; }
    public int Bowel { get; set; }
    public string Presenting_symptom { get; set; }
    public string Symptom_duration { get; set; }
    public string Other_History { get; set; }
    //public string Clinical_examination { get; set; }
    public int Performance_status { get; set; }
    public string Conscious { get; set; }
    public int GCS_E { get; set; }
    public int GCS_V { get; set; }
    public int GCS_M { get; set; }
    public string Pallor { get; set; }
    public string Icterus { get; set; }
    public string Oedema { get; set; }
    public string Cyanosis { get; set; }
    public string Clubbing { get; set; }
    public string Vitals { get; set; }
    public string PR { get; set; }
    public string BP { get; set; }
    public string Temp { get; set; }
    public int Pain_score { get; set; }
    public string Systemic_examination { get; set; }
    public string Head_and_neck { get; set; }
    public string CNS_Exam { get; set; }
    public string Respiratory { get; set; }
    public string Breast { get; set; }
    public string Abdomen { get; set; }
    public string Gynec_exam { get; set; }
    public string GU_examination { get; set; }
    public string Lymph_nodal_stations { get; set; }
    public string Other_findings { get; set; }
    public string Preliminary_diagnosis { get; set; }
    public int Site { get; set; }
    public string S_TNM { get; set; }
    public string S_T { get; set; }
    public string S_N { get; set; }
    public string S_M { get; set; }
    public string Stage { get; set; }
    public string Differential_diagnosis { get; set; }
    public string Investigations_proposed { get; set; }
    public DateTime Next_visit_date { get; set; }
    public int investigationtype;
    public DateTime investigationdate;
    public string inestigationfinding;
    public string Submission_status;
    public string submittedby;
    public string Approvedby;
    public string userid;
    public int Roleid;
    public string co_morbities;
    public string clinicalexamdetails;
    public string clinicaltype;
    public string treatment_type;
    public int Disease_Site;
    public string consltantincharge;
    public DateTime approveddate;
    public DateTime submitted_date;
    public string Reworkcomment;
    public int surgerycount;
    public int radiocount;
    public int chemocount;
    public int clinicalcount;
    public int clinicalentryno;
    public int symptomcount;

    public string uploadFlag { get; set; }

    public string Testlocation { get; set; }

    public string source { get; set; }

    public int investigationcount { get; set; }
    public int tumotmarkercount;
    public int procedurecount;
    public int imagingcount;

    public string clustersource { get; set; }
    public string subclustersource;

    public int GWSurgerySavedEntryNo;
    public int GWRadioSavedEntryNo;
    public int GWChemoSavedEntryNo;
    public int ClinicalExamTypeSavedEntryNo;
    //GICOLO
    public string DropdownTreatment;

    public string Tub_GICOLO_Extentofcopy;
    public string Tub_GICOLO_Locationoflesion;
    public string Tub_GICOLO_DistancefromAnalverge;
    public string Tub_GICOLO_Typeoflesion;
    public string Tub_GICOLO_Tumourlength;
    public string Tub_GICOLO_Skiplesion;
    public string Tub_GICOLO_CompleteOcclusion;
    public string Tub_GICOLO_PresenceofadenomaPolyps;
    public string Tub_GICOLO_NoofAdenoma;
    public string Tub_GICOLO_Location;

    public string Tub_GICOLO_Interventionforpolyp;
    public string habitsdurationvalue;
    public int symptomdurationvalue;
    public string lymphnodetxt;
    public string Tub_GIStomach_Stent;//SN-30-03-2020
    public string Tub_GIStomach_StentDetails;//SN-30-03-2020
    public int cluster;

    public string treatGIEso;
    public string Distancefromincisor;
    public string typeoflesionGIEso;
    public string OGJlocation;
    public string Structure;
    public string StructureYes;
    public string PostRTChanges;
    public string treatresponseGIEso;
    public string Depthofinvasion;
    public string TstageGIEso;
    public string NstageGIEso;

    public int entrynoinvetsigation;
    public int entrynoTumormarker;
    public int entrynoProcedures;
    public int entrynoImaging;


    public string Thyroidnodule;
    public string Microcalcification;
    public string Cystic;
    public string ThyroidTIRADSscore;
    public string Lymphnodes;
    public string Thyroidlocation;
    public string Number;
    public string Thyroidnumberoftimesfnac;
    public string Bethesdacategory;
    public string Urine_Serum;//SN-20-04-2020



    public int SymptomSavedEntryNo { get; set; }

    public string othersubsite { get; set; }

    public object uploadflag { get; set; }

    public string OtherInvestigation { get; set; }

    public string OtherInvestigationDetails { get; set; }

    public string investigationpath { get; set; }

    public int entrynocheckinvestigation { get; set; }

    public int entrynochecktumormarker { get; set; }

    public int Biopsy;
    public int pathologytype;
    public DateTime pathologydate;
    public string pathologyfinding;
    public string pathologyfilepath;
    public string pathologyTestlocation { get; set; }
    public string pathologysource { get; set; }
    public int pathologycount { get; set; }
    public int entrynopathology;
    public Double Paeds_Height;
    public Double Paeds_Weight;
    public Double Paeds_HeadCircumferance;
    public string Paeds_MUAC;
    public int entrynocheckprocedure { get; set; }

    public int entrynocheckimaging { get; set; }

    public int Habitscount { get; set; }

    public int HabitsSavedEntryNo { get; set; }

    public string studydata { get; set; }

    public string month { get; set; }

    public int YEAR;
   
    public string approvedby { get; set; }
    public string telNo { get; set; }

    public Double Height { get; set; }

    public Double Weight { get; set; }

    public int Length;
    public string metastatic;
    public DateTime Date;

    public DateTime thirtydaysafterDate;
    public string Type;

    public string GW_Status;
    public string TMB_Status;

    public string PIA_Status { get; set; }

    public string POA_Status { get; set; }
    public string PSA_Status;
    //08-07-2021
    public string IsProxy;
}

public class LastVisitedDetails
{
    public string txtunitvisitedsame = "";
    public string txtconsultantvistedsame = "";
    public string txtdatevisted = "";
}