﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using log4net;
using System.Collections;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
public class DataAccess
{
    private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    public string cmdString;
    public string str;
    public MySqlConnection con1;
    public MySqlCommand cmd1;
    MySqlTransaction transaction;

    public DataAccess()
    {
        cmdString = "";
        str = ConfigurationManager.ConnectionStrings["EMRConnectionString"].ConnectionString;
        con1 = new MySqlConnection(str);
        cmd1 = new MySqlCommand(cmdString, con1);
    }
    public System.Collections.ArrayList GetUserRole(string userid)
    {
        log.Debug("  Inside GetUserRole function  of userid " + userid + " ");

        try
        {

            con1.Open();
            //cmd = new MySqlCommand("Select RoleId from User_Role_Map where UserId='"+ userid + "'", con);
            cmd1 = new MySqlCommand("select RoleID from user_role_map where User_Id=@User_Id", con1);
            cmd1.CommandType = CommandType.Text;
            cmd1.Parameters.AddWithValue("@User_Id", userid);
            MySqlDataReader sdr = cmd1.ExecuteReader();
            ArrayList rolelist = new ArrayList();
            string role = "";

            while (sdr.Read())
            {
                if (!Convert.IsDBNull(sdr["Role_ID"]))
                {
                    role = (string)sdr["Role_ID"];
                }
                rolelist.Add(role);
            }
            return rolelist;
        }
        catch (Exception e)
        {
            log.Error(" Error Inside GetUserRole function  of userid " + userid + " ");
            return null;
        }
        finally
        {
            con1.Close();
        }
    }

    public StudentDatam Get_UserDetails(string emailid, string Pass)
    {
        log.Debug("DataAccess.cs : inside Get_UserDetails function for EmailID: " + emailid);
        try
        {
            StudentDatam user = new StudentDatam();
            user.userid = "userid not found";
            con1.Open();
            cmd1 = new MySqlCommand("select u.User_Id,EmailId,User_Name,Active, r.RoleId from User_M u, User_Role_Map r where r.User_Id=u.User_Id and EmailID = @Email and u.User_Id=@user_id", con1);
            cmd1.CommandType = CommandType.Text;
            cmd1.Parameters.AddWithValue("@Email", emailid);
            cmd1.Parameters.AddWithValue("@user_id", Pass);
            MySqlDataReader sdr = cmd1.ExecuteReader();

            while (sdr.Read())
            {

                if (!Convert.IsDBNull(sdr["User_Id"]))
                {
                    user.userid = (string)sdr["User_Id"];
                }

                if (!Convert.IsDBNull(sdr["RoleId"]))
                {
                    user.role = (string)sdr["RoleId"];
                }
                else
                {
                    user.role = "";
                }
                    
                if (!Convert.IsDBNull(sdr["Active"]))
                {
                    user.isactive = (string)sdr["Active"];
                }
                if (!Convert.IsDBNull(sdr["User_Name"]))
                {
                    user.username = (string)sdr["User_Name"];
                }

                if (!Convert.IsDBNull(sdr["EmailId"]))
                {
                    user.emailid = (string)sdr["EmailId"];
                }
                
            }
            log.Info("DataAccessObject.cs : inside Get_UserDetails function returning for for emailid: " + emailid);
            return user;
        }
        catch (Exception e)
        {
            log.Error("DataAccessObject.cs : Exception caught for Get_UserDetails for emailid :'" + emailid + "'");
            log.Error(" Error Message" + e);
            log.Error(" Stack Trace " + e.StackTrace);
            throw e;

        }
        finally
        {
            con1.Close();
        }
    }
}