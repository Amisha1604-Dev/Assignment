﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using log4net;
using System.Collections;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;

/// </summary>
public class DALEMR
{
    private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    public string cmdString;
    public string str;
    public MySqlConnection con;
    public MySqlCommand cmd;
    MySqlTransaction transaction;

    public DALEMR()
    {
        cmdString = "";
        str = ConfigurationManager.ConnectionStrings["EMRConnectionString"].ConnectionString;
        con = new MySqlConnection(str);
        cmd = new MySqlCommand(cmdString, con);
    }
   

    public int insertPatientData(Student d1)
    {
        log.Debug("Inside insertPatientData function to of Student Name:" + d1.StudentName + "Roll Number: " + d1.RollNo);
        int result = 0, seed = 0; string Initial = "";
        string seedFinal = "", PatientID = "", result1="";
        con = new MySqlConnection(str);
        con.Open();
        
        try
        {
                cmdString = "insert into student_reg (StdRollNo,StdName,AadharNo,DOB,Gender,Mobile_No,EmailID,Father_Name,Mother_Name,Doc_Path) values (@StdRollNo,@StdName,@AadharNo,@DOB,@Gender,@Mobile_No,@EmailID,@Father_Name,@Mother_Name,@Doc_Path)";
                cmd = new MySqlCommand(cmdString, con);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@StdRollNo", d1.RollNo);               
                cmd.Parameters.AddWithValue("@StdName", d1.StudentName );
                cmd.Parameters.AddWithValue("@AadharNo", d1.AadharNo);
                cmd.Parameters.AddWithValue("@DOB", d1.DOB);
                cmd.Parameters.AddWithValue("@Gender", d1.Gender);
                cmd.Parameters.AddWithValue("@Mobile_No", d1.MobileNo);
                cmd.Parameters.AddWithValue("@EmailID", d1.EmailID);
                cmd.Parameters.AddWithValue("@Father_Name", d1.FName);
                cmd.Parameters.AddWithValue("@Mother_Name", d1.Mname);
            cmd.Parameters.AddWithValue("@Doc_Path", d1.DocPath);

            result = cmd.ExecuteNonQuery();
            
              

            return result;

        }

        catch (Exception ex)
        {
            log.Error("Inside DALEMR- insertPatientData catch block ");
            log.Error(ex.Message);
            log.Error(ex.StackTrace);

            
            throw ex;
        }

        finally
        {
            con.Close();
        }
    }
    public List<Student> SelectPatientDetails()
    {
        var patients = new List<Student>();
        using (MySqlConnection con = new MySqlConnection(str))
        {
            con.Open();
            try
            {
                using (MySqlCommand cmd = new MySqlCommand("select * from Student_Reg", con))
                {
                    cmd.CommandType = CommandType.Text;
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var patient = new Student
                            {
                                
                                RollNo = reader["StdRollNo"].ToString(),
                                StudentName = reader["StdName"].ToString(),
                                AadharNo = reader["AadharNo"].ToString(),
                                Gender = reader["Gender"].ToString(),
                                MobileNo = reader["Mobile_No"].ToString(),
                                EmailID = reader["EmailID"].ToString(),
                                FName = reader["Father_Name"].ToString(),
                                Mname = reader["Mother_Name"].ToString(),
                                DOB = reader["DOB"].ToString(),
                                DocPath = reader["Doc_Path"].ToString(),
                            };
                            patients.Add(patient);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
                log.Error(ex.StackTrace);
                throw; // Use "throw;" to preserve the stack trace
            }
        }
        return patients;
    }
}

