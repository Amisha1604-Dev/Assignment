﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Security.Cryptography;
using System.IO;
using System.Text;
using log4net;
using System.Configuration;
using MySql.Data.MySqlClient;


public partial class Login : System.Web.UI.Page
{
    private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    protected void Page_Load(object sender, EventArgs e)
    {
        log4net.Config.XmlConfigurator.Configure();
        
        if (!IsPostBack)
        {
            LoadPage();
        }
    }
    private void LoadPage()
    {
        txtUsername.Text = "";
        txtPassword.Text = "";
       
        txtUsername.Focus();
    }

    
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        StudentDatam loginDATA = new StudentDatam();
        Business b = new Business();
        loginDATA = b.Get_UserDetails(txtUsername.Text, txtPassword.Text);
        if (loginDATA.role != "")
        {
            
                if ((loginDATA.role != "")) //28
                {
                    if (loginDATA.isactive == "Y" || loginDATA.isactive == "y")
                    {//dec14
                       
                        Session["Role"] = loginDATA.role;
                        Session["UserID"] = loginDATA.userid;
                        Session["UserName"] = loginDATA.username;
                        Session["Type"] = loginDATA.Type;

                        //if (loginDATA.role == 1 || loginDATA.role == 5 || loginDATA.role == 6 || loginDATA.role == 7) nov 27
                        if (loginDATA.role == "1")  //nov 27
                        {
                            Response.Redirect("./StudentRegistration/Student_Search.aspx", false);

                        }                        
                                                                 
                        else
                        {

                            Response.Redirect("./StudentRegistration/Student_Search.aspx", false);
                        }                      
                    }
                    else
                    {
                        
                        return;
                    }
                }
                else
                {
                    log.Info("Login Error" + loginDATA.role + loginDATA.emailid);
                    
                   
                    return;
                }
            
           
        }
        else
        {
            log.Info("Login Error" + loginDATA.role + loginDATA.emailid);
            
           
            return;
        }
    }
    private string Encrypt(string clearText)
    {
        string EncryptionKey = "MAKV2SPBNI99212";


        byte[] clearBytes = Encoding.Unicode.GetBytes(clearText);
        using (Aes encryptor = Aes.Create())
        {
            Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
            encryptor.Key = pdb.GetBytes(32);
            encryptor.IV = pdb.GetBytes(16);
            using (MemoryStream ms = new MemoryStream())
            {
                using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                {
                    cs.Write(clearBytes, 0, clearBytes.Length);
                    cs.Close();
                }
                clearText = Convert.ToBase64String(ms.ToArray());
            }
        }
        return clearText;
    }

}