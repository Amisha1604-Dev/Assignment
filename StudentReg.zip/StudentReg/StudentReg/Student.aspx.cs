﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Collections;
using System.IO;
using System.Configuration;
using log4net;
using AjaxControlToolkit;
using System.Globalization;
using System.Text;
using MySql.Data.MySqlClient;
public partial class StudentReg_Student : System.Web.UI.Page
{
    private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);  
    protected void Page_Load(object sender, EventArgs e)
    {
        
        string rollNo = txtRollnumber.Text;
        
        if (!IsPostBack)
        {
            
        }
    }
    
    public void Clear()
    {
        txtAadhar.Text = string.Empty;
        txtRollnumber.Text = string.Empty;
        txtSname.Text = string.Empty;
        txtage.Text = string.Empty;
        ddlGender.SelectedValue = "";
        txtmblno.Text = string.Empty;
        txtemailid.Text = string.Empty;
        txtFN.Text = string.Empty;
        txtMname.Text = string.Empty;

    }
    protected void Btn_Save(object sender, EventArgs e)
    {
        Business b = new Business();
      

        Student d = new Student();
        log.Debug("Patient entry: Btn_Save");
        try
        {
            if (txtRollnumber.Text.Trim()==""|| txtRollnumber.Text==null)
            {
                string EnterHospNo = "Swal.fire({ icon: 'warning', text: 'Please Enter Roll Number'});";
                ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "CloseWindow", EnterHospNo, true);
                return;
            }
            if (txtAadhar.Text.Trim() == "" || txtAadhar.Text == null)
            {
                string EnterHospNo = "Swal.fire({ icon: 'warning', text: 'Please Enter Aadhar Number', height: 200, width: 400 });";
                ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "CloseWindow", EnterHospNo, true);
                return;
            }
            if (txtSname.Text.Trim() == "" || txtSname.Text == null)
            {
                string EnterHospNo = "Swal.fire({ icon: 'warning', text: 'Please Enter Student Name', height: 200, width: 400 });";
                ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "CloseWindow", EnterHospNo, true);
                return;
            }

            if (txtmblno.Text.Trim() == "" || txtmblno.Text == null)
            {
                string EnterHospNo = "Swal.fire({ icon: 'warning', text: 'Please Enter Mobile Number', height: 200, width: 400 });";
                ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "CloseWindow", EnterHospNo, true);
                return;
            }
            
            d.AadharNo = txtAadhar.Text;
            d.RollNo = txtRollnumber.Text.Trim();
            d.StudentName = txtSname.Text.Trim();
            d.DOB = txtage.Text.Trim();
            d.Gender = ddlGender.SelectedValue;
            d.MobileNo = txtmblno.Text.Trim();
            d.EmailID = txtemailid.Text;
            d.FName = txtFN.Text.Trim();
            d.Mname = txtMname.Text.Trim();
            btnUpload_Click(sender,e);
            d.DocPath = Session["Path"].ToString();
            int result = 0;
            result = b.insertPatientData(d);
            
            
            if (result > 0)
            {
                //string SuccessPopup = "Swal.fire({ icon: 'success', title: 'Patient Details Saved Sucessfully', height: 200, width: 300 });";
                //string SuccessPopup = "Swal.fire({ icon: 'warning', text: 'Please review the Aadhar Number "+ txtAadhar.Text+" and Hospital Number "+ txtHosptlNo.Text+ " Is Correct click on continue', height: 300, width: 500, showCancelButton: true, confirmButtonText: 'Continue', cancelButtonText: 'Cancel' }).then((result) => { if (result.isConfirmed) { Swal.fire('Continued!', 'Patient Details saved Sucessfully', 'success').then(function() { window.location.href = 'Patient_Reg.aspx'; }); } else if (result.dismiss === Swal.DismissReason.cancel) { Swal.fire('Cancelled', 'error'); } });";
                string successMessage = "Swal.fire({ icon: 'success', title: 'Student Registered Successfully'});";
                ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "CloseWindow", successMessage, true);
                Clear();
               
            }
            else
            {
                string CloseWindow = "Swal.fire({ icon: 'error', title: 'Error'});";
                ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "CloseWindow", CloseWindow, true);                
            }
        }
        catch (Exception ex)
        {
            log.Error("Inside Catch Block Of Individual feedback Btn_Save function " + ex.Message);
            log.Error(ex.StackTrace);
            //log.Error(ex.Message);
            if (ex.Message.Contains("Cannot insert duplicate key in object"))
            {
                //string CloseWindow = "alert('Hospital Number already Present')";
                string CloseWindow = "Swal.fire({ icon: 'error', title: 'Student already Registered', customClass: { title: 'custom-title-class'}});";
                //string CloseWindow = "Swal.fire({ icon: 'error', title: 'Hospital Number already Present', customClass: { popup: 'swal2-show', icon: 'swal2-animate-error-icon' } });";
                ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "CloseWindow", CloseWindow, true);

            }
            if (ex.Message.Contains("Duplicate entry"))
            {
                //string CloseWindow = "alert('Hospital Number already Present')";
                string CloseWindow = "Swal.fire({ icon: 'error', title: 'Student already Registered', customClass: { title: 'custom-title-class'}});";
                //string CloseWindow = "Swal.fire({ icon: 'error', title: 'Hospital Number already Present', customClass: { popup: 'swal2-show', icon: 'swal2-animate-error-icon' } });";
                ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "CloseWindow", CloseWindow, true);

            }
            else
            {
                string CloseWindow = "Swal.fire({ icon: 'error', title: 'Error'});";
                ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "CloseWindow", CloseWindow, true);
            }
            return;
        }
    }
    
    protected void btn_Cancel(object sender, EventArgs e)
    {
        //Response.Redirect("~/EMR/Patient_Reg.aspx");
    }
  
    protected void GridView2_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        ImageButton EditButton = (ImageButton)e.Row.FindControl("BtnEdit");
    }
  
    protected void btnSearchPatient_Click(object sender, EventArgs e)
    {


    }
    protected void btnUpload_Click(object sender, EventArgs e)
    {
        // Check if the file has been uploaded
        if (FileUpload1.HasFile)
        {
            try
            {
                // Get the file name and the file extension
                string fileName = Path.GetFileName(FileUpload1.PostedFile.FileName);
                string fileExtension = Path.GetExtension(fileName).ToLower();

                // Validate file type (e.g., only allow PDF or image files)
                if (fileExtension == ".pdf" || fileExtension == ".jpg" || fileExtension == ".jpeg" || fileExtension == ".png")
                {
                    // Define the path to store the uploaded file
                    string uploadDirectory = Server.MapPath("~/Uploads/");

                    // Check if the directory exists, if not, create it
                    if (!Directory.Exists(uploadDirectory))
                    {
                        Directory.CreateDirectory(uploadDirectory);
                    }

                    // Define the file path
                    string filePath = Path.Combine(uploadDirectory, fileName);

                    // Save the uploaded file to the server
                    FileUpload1.SaveAs(filePath);
                    Session["Path"] = filePath;
                    // Show a success message
                  
                }
                else
                {
                    // If file type is invalid
                    string CloseWindow = "Swal.fire({ icon: 'error', title: 'Invalid file type. Only PDF, JPG, JPEG, PNG are allowed.'});";
                    ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "CloseWindow", CloseWindow, true);
                    
                    return;
                }
            }
            catch (Exception ex)
            {
                // If any error occurs
                string CloseWindow = "Swal.fire({ icon: 'error', title: 'Error uploading file'});";
                ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "CloseWindow", CloseWindow, true);               
                return;
            }
        }
        else
        {
            // If no file is selected
            string CloseWindow = "Swal.fire({ icon: 'error', title: 'Please select a file to upload.'});";
            ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "CloseWindow", CloseWindow, true);
            return;
        }
    }
}





